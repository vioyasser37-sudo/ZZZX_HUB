package com.devcheck.gamebooster;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private LinearLayout appList;
    private EditText searchBox;
    private List<ResolveInfo> launchableApps = new ArrayList<>();
    private String currentSearch = "";
    private boolean reducedMotion = false;
    private boolean hasShownDashboard = false;
    private Button overlayGrantButton;

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(7, 11, 20));
        w.setNavigationBarColor(Color.rgb(7, 11, 20));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 801);
        }
        showSplash();
    }

    private GradientDrawable bg(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false); b.setTextColor(Color.rgb(7, 11, 20));
        b.setTextSize(14); b.setTypeface(Typeface.DEFAULT_BOLD); b.setBackground(bg(Color.rgb(94, 235, 255), Color.TRANSPARENT, 14));
        b.setPadding(dp(14), dp(7), dp(14), dp(7)); return b;
    }

    private TextView cardLabel(String label) {
        TextView t = text(label, 16, Color.WHITE, true); t.setPadding(0, 0, 0, dp(6)); return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(15), dp(16), dp(15));
        c.setBackground(bg(Color.rgb(15, 23, 39), Color.rgb(34, 54, 75), 18));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 0, 0, dp(12)); c.setLayoutParams(p); return c;
    }

    private void showSplash() {
        LinearLayout root = new LinearLayout(this); root.setGravity(Gravity.CENTER); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(28), dp(28), dp(28), dp(28)); root.setBackgroundColor(Color.rgb(7,11,20));
        TextView emblem = text("NOVA", 38, Color.rgb(94,235,255), true); emblem.setLetterSpacing(0.18f);
        TextView title = text("GAME BOOSTER", 19, Color.WHITE, true); title.setLetterSpacing(0.12f);
        TextView subtitle = text("FLOATING TOOLS  •  GAME LAUNCHER", 10, Color.rgb(145,173,194), false); subtitle.setPadding(0, dp(12), 0, dp(20));
        ProgressBar bar = new ProgressBar(this); bar.setIndeterminate(true);
        root.addView(emblem); root.addView(title); root.addView(subtitle); root.addView(bar);
        setContentView(root);
        ScaleAnimation pulse = new ScaleAnimation(.92f, 1.03f, .92f, 1.03f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
        pulse.setDuration(650); pulse.setRepeatMode(Animation.REVERSE); pulse.setRepeatCount(Animation.INFINITE); emblem.startAnimation(pulse);
        handler.postDelayed(() -> { emblem.clearAnimation(); showDashboard(); }, 3000);
    }

    private void showDashboard() {
        hasShownDashboard = true;
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(Color.rgb(7, 11, 20));
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(15), dp(18), dp(24)); scroll.addView(root);

        TextView top = text("NOVA  /  GAME SESSION", 11, Color.rgb(94,235,255), true); top.setLetterSpacing(.12f); root.addView(top);
        TextView hero = text("Game Booster", 29, Color.WHITE, true); hero.setPadding(0, dp(8), 0, dp(4)); root.addView(hero);
        TextView intro = text("Launcher aplikasi + floating tools. Fitur ini tidak mengubah pengaturan CPU/GPU sistem.", 13, Color.rgb(153,173,196), false); intro.setPadding(0, 0, 0, dp(18)); root.addView(intro);

        LinearLayout perm = card(); root.addView(perm); perm.addView(cardLabel("01  /  Floating permission"));
        perm.addView(text("Izinkan tampil di atas aplikasi lain agar tombol mengambang dan crosshair dapat terlihat saat game terbuka.", 13, Color.rgb(178,194,212), false));
        Button grant = button(Settings.canDrawOverlays(this) ? "Overlay permission: granted" : "Izinkan floating overlay");
        overlayGrantButton = grant;
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2); gp.topMargin = dp(10); perm.addView(grant, gp);
        grant.setOnClickListener(v -> {
            if (Settings.canDrawOverlays(this)) { startOverlayService(OverlayService.ACTION_START); Toast.makeText(this, "Floating panel diaktifkan", Toast.LENGTH_SHORT).show(); }
            else { try { Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())); startActivity(i); } catch (Exception e) { Toast.makeText(this, "Buka Settings dan cari izin tampil di atas aplikasi", Toast.LENGTH_LONG).show(); } }
        });

        LinearLayout tools = card(); root.addView(tools); tools.addView(cardLabel("02  /  Quick tools"));
        TextView toolCopy = text("Panel bisa dipindah dengan drag dan menampilkan timer sesi. Tutup kapan saja dari panel mengambang.", 13, Color.rgb(178,194,212), false); tools.addView(toolCopy);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0, dp(8), 0, 0); tools.addView(row);
        Button floating = button("Aktifkan panel"); Button cross = button("Timer sesi");
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, -2, 1); half.setMargins(0, 0, dp(6), 0); row.addView(floating, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, -2, 1); half2.setMargins(dp(6), 0, 0, 0); row.addView(cross, half2);
        floating.setOnClickListener(v -> ensureOverlayThen(OverlayService.ACTION_START));
        cross.setOnClickListener(v -> ensureOverlayThen(OverlayService.ACTION_SESSION));

        LinearLayout info = card(); root.addView(info); info.addView(cardLabel("03  /  Refresh rate note"));
        info.addView(text("Pilihan 60/90/120/144 FPS pada aplikasi web hanya mengatur target animasi demo. Aplikasi biasa tidak dapat memaksa panel HP berubah ke 144 Hz. Atur refresh rate asli lewat Setelan layar jika perangkat mendukungnya.", 13, Color.rgb(178,194,212), false));

        LinearLayout appCard = card(); root.addView(appCard); appCard.addView(cardLabel("04  /  Apps on this device"));
        appCard.addView(text("Pilih aplikasi di bawah untuk melihat animasi start lalu membuka aplikasi tersebut. Untuk animasi ini berlaku saat dibuka dari launcher NOVA.", 13, Color.rgb(178,194,212), false));
        searchBox = new EditText(this); searchBox.setSingleLine(true); searchBox.setTextColor(Color.WHITE); searchBox.setHintTextColor(Color.rgb(110,132,155)); searchBox.setHint("Cari aplikasi...");
        searchBox.setPadding(dp(12), dp(8), dp(12), dp(8)); searchBox.setBackground(bg(Color.rgb(7,13,24), Color.rgb(38,62,82), 12));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2); sp.topMargin = dp(12); appCard.addView(searchBox, sp);
        appList = new LinearLayout(this); appList.setOrientation(LinearLayout.VERTICAL); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(8); appCard.addView(appList, lp);
        loadApps(); renderApps("");
        searchBox.addTextChangedListener(new TextWatcher() { public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){ currentSearch=s.toString(); renderApps(currentSearch); } public void afterTextChanged(Editable e){} });
        TextView foot = text("NOVA v1.0  •  Overlay requires explicit Android permission  •  No root", 10, Color.rgb(103,128,150), false); foot.setGravity(Gravity.CENTER); foot.setPadding(0, dp(8), 0, 0); root.addView(foot);
        setContentView(scroll);
        AlphaAnimation fade = new AlphaAnimation(0f, 1f); fade.setDuration(300); scroll.startAnimation(fade);
    }

    private void ensureOverlayThen(String action) {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this).setTitle("Izin floating diperlukan")
                    .setMessage("Aktifkan izin 'Tampil di atas aplikasi lain' terlebih dahulu.")
                    .setNegativeButton("Batal", null).setPositiveButton("Buka Settings", (d,w) -> {
                        try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); }
                        catch (Exception e) { Toast.makeText(this, "Buka pengaturan izin overlay secara manual.", Toast.LENGTH_LONG).show(); }
                    }).show(); return;
        }
        startOverlayService(action);
    }

    private void startOverlayService(String action) {
        Intent i = new Intent(this, OverlayService.class); i.setAction(action);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void loadApps() {
        Intent query = new Intent(Intent.ACTION_MAIN, null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        launchableApps = pm.queryIntentActivities(query, 0);
        final String self = getPackageName();
        List<ResolveInfo> filtered = new ArrayList<>();
        for (ResolveInfo info : launchableApps) if (info.activityInfo != null && !self.equals(info.activityInfo.packageName)) filtered.add(info);
        Collections.sort(filtered, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString());
            }
        });
        launchableApps = filtered;
    }

    private void renderApps(String q) {
        if (appList == null) return; appList.removeAllViews();
        String needle = q == null ? "" : q.trim().toLowerCase(Locale.ROOT); int count = 0;
        for (ResolveInfo app : launchableApps) {
            String label = app.loadLabel(getPackageManager()).toString();
            if (!label.toLowerCase(Locale.ROOT).contains(needle)) continue;
            LinearLayout item = new LinearLayout(this); item.setGravity(Gravity.CENTER_VERTICAL); item.setOrientation(LinearLayout.HORIZONTAL);
            item.setPadding(dp(10), dp(9), dp(10), dp(9)); item.setBackground(bg(Color.rgb(8,15,27), Color.rgb(28,44,62), 12));
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.setMargins(0, 0, 0, dp(7)); appList.addView(item, ip);
            TextView icon = text("APP", 10, Color.rgb(94,235,255), true); icon.setGravity(Gravity.CENTER); icon.setBackground(bg(Color.rgb(22,43,58), Color.rgb(39,86,102), 10));
            item.addView(icon, new LinearLayout.LayoutParams(dp(42), dp(42)));
            LinearLayout nameStack = new LinearLayout(this); nameStack.setOrientation(LinearLayout.VERTICAL); nameStack.setPadding(dp(10), 0, dp(6), 0);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, -2, 1); item.addView(nameStack, nlp);
            nameStack.addView(text(label, 14, Color.WHITE, true));
            nameStack.addView(text(app.activityInfo.packageName, 9, Color.rgb(110,133,155), false));
            TextView launch = text("START  ›", 11, Color.rgb(94,235,255), true); item.addView(launch);
            item.setOnClickListener(v -> launchApp(app.activityInfo.packageName, label)); count++;
        }
        if (count == 0) { TextView empty = text("Aplikasi tidak ditemukan atau tidak terlihat oleh Android.", 12, Color.rgb(140,160,180), false); empty.setPadding(0, dp(12), 0, dp(12)); appList.addView(empty); }
    }

    private void launchApp(String packageName, String label) {
        if (Settings.canDrawOverlays(this)) startOverlayService(OverlayService.ACTION_SESSION);
        PackageManager pm = getPackageManager(); Intent launch = pm.getLaunchIntentForPackage(packageName);
        if (launch == null) { Toast.makeText(this, "Tidak ada halaman launcher untuk aplikasi ini.", Toast.LENGTH_SHORT).show(); return; }
        LinearLayout splash = new LinearLayout(this); splash.setGravity(Gravity.CENTER); splash.setOrientation(LinearLayout.VERTICAL); splash.setBackgroundColor(Color.rgb(7,11,20));
        TextView tag = text("NOVA SESSION START", 12, Color.rgb(94,235,255), true); tag.setLetterSpacing(.16f);
        TextView title = text(label, 27, Color.WHITE, true); title.setGravity(Gravity.CENTER); title.setPadding(dp(24), dp(12), dp(24), dp(10));
        TextView status = text("Preparing visual overlay...", 12, Color.rgb(151,174,195), false);
        ProgressBar bar = new ProgressBar(this); bar.setIndeterminate(true);
        appList = null;
        splash.addView(tag); splash.addView(title); splash.addView(status); splash.addView(bar); setContentView(splash);
        ScaleAnimation scale = new ScaleAnimation(.88f, 1f, .88f, 1f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f); scale.setDuration(850); title.startAnimation(scale);
        AlphaAnimation alpha = new AlphaAnimation(.2f, 1f); alpha.setDuration(850); tag.startAnimation(alpha);
        handler.postDelayed(() -> {
            try { launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); }
            catch (ActivityNotFoundException e) { Toast.makeText(this, "Aplikasi gagal dibuka.", Toast.LENGTH_LONG).show(); showDashboard(); }
        }, 1300);
    }

    @Override protected void onResume() {
        super.onResume();
        // The dashboard is recreated when returning to the app if it was previously left on the permission screen.
        if (hasShownDashboard && appList == null && handler != null) handler.postDelayed(() -> { if (!isFinishing() && appList == null) showDashboard(); }, 250);
        if (hasShownDashboard && overlayGrantButton != null && Settings.canDrawOverlays(this)) overlayGrantButton.setText("Overlay permission: granted");
    }

    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
