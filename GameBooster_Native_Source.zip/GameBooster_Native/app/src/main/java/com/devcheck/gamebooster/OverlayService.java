package com.devcheck.gamebooster;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class OverlayService extends Service {
    public static final String ACTION_START = "com.devcheck.gamebooster.START_OVERLAY";
    public static final String ACTION_SESSION = "com.devcheck.gamebooster.START_SESSION_TIMER";
    public static final String ACTION_STOP = "com.devcheck.gamebooster.STOP_OVERLAY";
    private static final String CHANNEL_ID = "nova_game_session";
    private static final int NOTIFICATION_ID = 4201;

    private WindowManager wm;
    private View bubbleView;
    private View panelView;
    private WindowManager.LayoutParams bubbleParams;
    private WindowManager.LayoutParams panelParams;
    private TextView timerText;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean sessionRunning = false;
    private boolean timerPaused = false;
    private long sessionStartMs = 0L;
    private long pausedTotalMs = 0L;
    private long pauseStartedMs = 0L;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }

    @Override public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, makeNotification());
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            closeOverlays(); stopForeground(true); stopSelf(); return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Izinkan tampil di atas aplikasi lain terlebih dahulu.", Toast.LENGTH_LONG).show();
            stopForeground(true); stopSelf(); return START_NOT_STICKY;
        }
        if (ACTION_SESSION.equals(action)) {
            sessionRunning = true; timerPaused = false; sessionStartMs = SystemClock.elapsedRealtime(); pausedTotalMs = 0L; pauseStartedMs = 0L;
            showPanel();
        } else {
            showBubble();
        }
        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "NOVA floating game tools", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Persistent notification for user-controlled floating session timer");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        return b.setContentTitle("NOVA Game Booster")
                .setContentText("Floating session tools aktif")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }

    private GradientDrawable shape(int fill, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(fill); d.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) d.setStroke(dp(1), stroke);
        return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT); return t;
    }

    private Button toolButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextSize(12); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.rgb(7,11,20)); b.setPadding(dp(8), dp(2), dp(8), dp(2));
        b.setBackground(shape(Color.rgb(94,235,255), Color.TRANSPARENT, 11)); return b;
    }

    private WindowManager.LayoutParams overlayParams(int width, int height) {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(width, height, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
    }

    private void showBubble() {
        if (bubbleView != null) return;
        removePanelOnly();
        TextView bubble = label("N", 22, Color.rgb(94,235,255), true);
        bubble.setGravity(Gravity.CENTER); bubble.setBackground(shape(Color.rgb(10,22,36), Color.rgb(94,235,255), 32));
        bubble.setElevation(dp(8));
        bubbleParams = overlayParams(dp(62), dp(62)); bubbleParams.gravity = Gravity.TOP | Gravity.START; bubbleParams.x = dp(12); bubbleParams.y = dp(180);
        installDrag(bubble, bubbleParams, true);
        try { wm.addView(bubble, bubbleParams); bubbleView = bubble; }
        catch (Exception e) { Toast.makeText(this, "Panel mengambang tidak bisa ditampilkan di perangkat ini.", Toast.LENGTH_LONG).show(); }
    }

    private void showPanel() {
        if (panelView != null) { updateTimerText(); return; }
        removeBubbleOnly();
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(14), dp(12), dp(14), dp(14)); panel.setBackground(shape(Color.rgb(8,15,28), Color.rgb(94,235,255), 20)); panel.setElevation(dp(12));
        TextView header = label("NOVA  /  SESSION", 11, Color.rgb(94,235,255), true); header.setLetterSpacing(.08f); header.setPadding(0, 0, 0, dp(8)); panel.addView(header);
        installDrag(header, null, false);
        TextView caption = label("WAKTU SESI", 10, Color.rgb(139,166,190), true); panel.addView(caption);
        timerText = label("00:00", 30, Color.WHITE, true); timerText.setPadding(0, dp(2), 0, dp(4)); panel.addView(timerText);
        TextView note = label("Timer lokal • bukan pengukur FPS", 10, Color.rgb(139,166,190), false); panel.addView(note);
        View line = new View(this); line.setBackgroundColor(Color.rgb(34,54,75)); LinearLayout.LayoutParams lineP = new LinearLayout.LayoutParams(-1, dp(1)); lineP.setMargins(0, dp(10), 0, dp(10)); panel.addView(line, lineP);
        Button pause = toolButton("Pause timer"); LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(42)); bp.setMargins(0, 0, 0, dp(7)); panel.addView(pause, bp);
        pause.setOnClickListener(v -> { togglePause(); pause.setText(timerPaused ? "Lanjutkan timer" : "Pause timer"); updateTimerText(); });
        Button minimize = toolButton("Minimalkan panel"); LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, dp(42)); mp.setMargins(0, 0, 0, dp(7)); panel.addView(minimize, mp);
        minimize.setOnClickListener(v -> { removePanelOnly(); showBubble(); });
        Button end = toolButton("Akhiri sesi & tutup"); LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, dp(42)); panel.addView(end, ep);
        end.setOnClickListener(v -> { closeOverlays(); stopForeground(true); stopSelf(); });

        panelParams = overlayParams(dp(250), -2); panelParams.gravity = Gravity.TOP | Gravity.START; panelParams.x = dp(12); panelParams.y = dp(160);
        try { wm.addView(panel, panelParams); panelView = panel; updateTimerText(); scheduleTimerUpdate(); }
        catch (Exception e) { panelView = null; showBubble(); }
    }

    private void installDrag(View target, WindowManager.LayoutParams params, boolean isBubble) {
        final float[] startX = new float[1], startY = new float[1];
        final int[] originalX = new int[1], originalY = new int[1]; final boolean[] moved = new boolean[1];
        target.setOnTouchListener((v, event) -> {
            WindowManager.LayoutParams actual = params;
            if (!isBubble) actual = panelParams;
            if (actual == null) return false;
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX[0] = event.getRawX(); startY[0] = event.getRawY(); originalX[0] = actual.x; originalY[0] = actual.y; moved[0] = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - startX[0], dy = event.getRawY() - startY[0];
                    if (Math.abs(dx) > dp(4) || Math.abs(dy) > dp(4)) moved[0] = true;
                    actual.x = originalX[0] + (int) dx; actual.y = originalY[0] + (int) dy;
                    try { wm.updateViewLayout(isBubble ? bubbleView : panelView, actual); } catch (Exception ignored) {} return true;
                case MotionEvent.ACTION_UP:
                    if (isBubble && !moved[0]) showPanel(); return true;
                default: return false;
            }
        });
    }

    private void togglePause() {
        if (!sessionRunning) return;
        if (!timerPaused) { timerPaused = true; pauseStartedMs = SystemClock.elapsedRealtime(); }
        else { pausedTotalMs += SystemClock.elapsedRealtime() - pauseStartedMs; pauseStartedMs = 0L; timerPaused = false; }
    }

    private long elapsedMs() {
        if (!sessionRunning || sessionStartMs == 0L) return 0L;
        long end = timerPaused ? pauseStartedMs : SystemClock.elapsedRealtime();
        return Math.max(0L, end - sessionStartMs - pausedTotalMs);
    }

    private void scheduleTimerUpdate() {
        handler.removeCallbacks(timerRunnable); handler.post(timerRunnable);
    }

    private final Runnable timerRunnable = new Runnable() {
        @Override public void run() {
            updateTimerText();
            if (panelView != null) handler.postDelayed(this, 1000);
        }
    };

    private void updateTimerText() {
        if (timerText == null) return;
        long seconds = elapsedMs() / 1000L; long hours = seconds / 3600L; long minutes = (seconds % 3600L) / 60L; long remain = seconds % 60L;
        String value = hours > 0 ? String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, remain)
                : String.format(Locale.ROOT, "%02d:%02d", minutes, remain);
        timerText.setText(value);
    }

    private void removeBubbleOnly() {
        if (bubbleView != null) { try { wm.removeView(bubbleView); } catch (Exception ignored) {} bubbleView = null; }
    }

    private void removePanelOnly() {
        handler.removeCallbacks(timerRunnable);
        if (panelView != null) { try { wm.removeView(panelView); } catch (Exception ignored) {} panelView = null; }
        timerText = null;
    }

    private void closeOverlays() { removeBubbleOnly(); removePanelOnly(); }

    @Override public void onDestroy() {
        closeOverlays(); handler.removeCallbacksAndMessages(null); super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
