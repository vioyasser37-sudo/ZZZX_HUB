# NOVA Game Booster — Native Android source

Starter project for a native Android launcher with a floating session timer panel. This is intentionally **not** an HTML/WebView package: drawing above other apps and listing launchable applications require Android-native APIs and user-granted permissions.

## Included
- Native home screen with 3-second animated intro.
- Launchable-app list with search.
- Start animation before opening an app launched from NOVA.
- Floating bubble and draggable session timer panel.
- Pause/resume, minimize, and end-session controls.
- No root required.

## Important limits
- It does not promise to boost CPU/GPU performance, free system RAM, alter Android refresh rate, or raise device FPS. It is a launcher and floating session-tools app.
- The start animation runs when you launch an app from NOVA. It does not automatically intercept launches made from the home screen or other launchers.
- Android may prevent overlays in protected or full-screen apps; manufacturer settings and game policies also vary.
- This build deliberately omits an aiming/crosshair overlay. The floating panel offers a session timer and general controls instead.
- Overlay permission must be granted by the user in Android Settings. A persistent notification is used while the overlay service is running.
- The app queries launcher activities only. Android package visibility limits what apps can be discovered on newer versions.
- `FOREGROUND_SERVICE_SPECIAL_USE` and overlay behavior may require extra review or may be restricted by app stores. This project is intended for personal development/testing; review current policies before publishing.

## Build
Open this folder in Android Studio (JDK 17, Android SDK platform 35, Android Gradle Plugin 8.9.2 / Gradle 8.11.1), sync Gradle, and run `app` or select **Build > Build APK(s)**. The generated debug APK is normally placed at `app/build/outputs/apk/debug/app-debug.apk`.

No APK binary is included in this ZIP: the current environment does not have the Android SDK or Gradle installed to compile and sign it here.
