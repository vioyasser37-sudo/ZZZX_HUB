# Build notes

1. Import the extracted `GameBooster_Native` directory as an existing Android Studio project.
2. Install Android SDK Platform 35 and JDK 17 if prompted.
3. Sync Gradle and build the debug APK.
4. Install the APK on your own device. Open NOVA, grant “Display over other apps” when requested, then enable the floating panel.
5. In NOVA, tap an app in the list to see the start animation and launch it. The timer overlay is shown only if overlay permission is granted.

This is Android source code, not a ZIP for RFWeb2APK. A web-to-APK wrapper cannot grant native cross-app overlay behavior to an ordinary HTML page.
